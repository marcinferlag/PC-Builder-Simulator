import os
import sys

import webview


def resource_path(name):
    # When packaged with PyInstaller, files are unpacked to sys._MEIPASS.
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, name)


if __name__ == "__main__":
    html_file = resource_path("pc-simulator-v2.html")
    webview.create_window(
        "PC Builder Simulator",
        html_file,
        width=1280,
        height=820,
        resizable=True,
    )
    webview.start()
